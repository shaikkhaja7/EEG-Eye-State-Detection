from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView, PasswordResetView, PasswordChangeView
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.views import View
from django.contrib.auth.decorators import login_required
from django.conf import settings

import os
import numpy as np
import joblib

from users.models import UserPredictModel
from .forms import RegisterForm, LoginForm, UpdateUserForm, UpdateProfileForm
from users.forms import UserPredictDataForm


# ---------------------- LOAD MODEL ----------------------
MODEL_PATH = os.path.join(settings.BASE_DIR, "users", "EEGEye.pkl")

try:
    MODEL = joblib.load(MODEL_PATH)
    print("✅ Model loaded successfully:", MODEL_PATH)
except Exception as e:
    MODEL = None
    print("❌ Model load failed:", e)


# ---------------------- BASIC PAGES ----------------------
def home(request):
    return render(request, 'users/home.html')


@login_required(login_url='users-register')
def index(request):
    return render(request, 'app/index.html')


def Problem_Statement(request):
    return render(request, 'app/Problem_Statement.html')


def Basic_report(request):
    return render(request, 'app/Basic_report.html')


def Metrics_report(request):
    return render(request, 'app/Metrics_report.html')


# ---------------------- AUTH VIEWS ----------------------
class RegisterView(View):
    form_class = RegisterForm
    template_name = 'users/register.html'

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect(to='/')
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        form = self.form_class()
        return render(request, self.template_name, {'form': form})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)

        if form.is_valid():
            username = form.cleaned_data.get('username')
            form.save()
            messages.success(request, f'Account created for {username}')
            return redirect(to='login')

        return render(request, self.template_name, {'form': form})


class CustomLoginView(LoginView):
    form_class = LoginForm

    def form_valid(self, form):
        remember_me = form.cleaned_data.get('remember_me')

        if not remember_me:
            self.request.session.set_expiry(0)
            self.request.session.modified = True

        return super().form_valid(form)


class ResetPasswordView(SuccessMessageMixin, PasswordResetView):
    template_name = 'users/password_reset.html'
    email_template_name = 'users/password_reset_email.html'
    subject_template_name = 'users/password_reset_subject'
    success_url = reverse_lazy('users-home')
    success_message = "We've emailed you instructions for setting your password."


class ChangePasswordView(SuccessMessageMixin, PasswordChangeView):
    template_name = 'users/change_password.html'
    success_url = reverse_lazy('users-home')
    success_message = "Successfully Changed Your Password"


@login_required
def profile(request):
    if request.method == 'POST':
        user_form = UpdateUserForm(request.POST, instance=request.user)
        profile_form = UpdateProfileForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile is updated successfully')
            return redirect(to='users-profile')
    else:
        user_form = UpdateUserForm(instance=request.user)
        profile_form = UpdateProfileForm(instance=request.user.profile)

    return render(request, 'users/profile.html', {'user_form': user_form, 'profile_form': profile_form})


# ---------------------- PREDICTION VIEW ----------------------
def Deploy(request):
    """
    Takes 14 EEG channel values from form and predicts eye state using the ML model.
    """
    if request.method == 'POST':
        fields = ['AF3', 'F7', 'F3', 'FC5', 'T7', 'P7', 'O1', 'O2',
                  'P8', 'T8', 'FC6', 'F4', 'F8', 'AF4']

        form = UserPredictDataForm(request.POST)
        features = []

        for f in fields:
            features.append(float(request.POST.get(f)))

        Final_features = [np.array(features, dtype=float)]

        # Check ML model
        if MODEL is None:
            return render(request, 'app/result.html', {
                'form': form,
                'prediction_text': "❌ Model not loaded. Please check EEGEye.pkl"
            })

        prediction = MODEL.predict(Final_features)
        actual_output = int(prediction[0])

        # Label mapping
        if actual_output == 0:
            actual_output = 'EYECLOSED'
        elif actual_output == 1:
            actual_output = 'EYEOPEN'

        # Save to DB
        if form.is_valid():
            form_instance = form.save(commit=False)
            form_instance.eyeDetection = actual_output
            form_instance.save()

        return render(request, 'app/result.html', {
            'form': form,
            'prediction_text': actual_output
        })

    # GET request -> show form page
    form = UserPredictDataForm()
    return render(request, 'app/Deploy.html', {'form': form})


def Per_Database(request):
    models = UserPredictModel.objects.all()
    return render(request, 'app/Per_Database.html', {'models': models})

