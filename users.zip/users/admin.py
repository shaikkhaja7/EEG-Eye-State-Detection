from django.contrib import admin
from .models import Profile,UserPredictModel

admin.site.register(Profile)
admin.site.register(UserPredictModel)

