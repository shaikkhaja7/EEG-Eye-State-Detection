from django.urls import path
from .views import home,index, profile, RegisterView, Problem_Statement, Deploy, Per_Database, Basic_report, Metrics_report

urlpatterns = [
    path('', home, name='users-home'),
    path('register/', RegisterView.as_view(), name='users-register'),
    path('profile/', profile, name='users-profile'),
    path('index/', index, name='users-index'),
    path('Problem_Statement/', Problem_Statement, name='users-Problem_Statement'),
    path('Deploy/', Deploy, name='users-Deploy'),
    path('Per_Database/',Per_Database, name='users-Per_Database'),
    path('Basic_report/',Basic_report, name='users-Basic_report'),
    path('Metrics_report/',Metrics_report, name='users-Metrics_report'),
]
