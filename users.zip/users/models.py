from django.db import models
from django.contrib.auth.models import User 
from PIL import Image






# Extending User Model Using a One-To-One Link
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    avatar = models.ImageField(default='default.jpg', upload_to='profile_images')
    bio = models.TextField()

    def __str__(self):
        return self.user.username

    # resizing images
    def save(self, *args, **kwargs):
        super().save()

        img = Image.open(self.avatar.path)

        if img.height > 100 or img.width > 100:
            new_img = (100, 100)
            img.thumbnail(new_img)
            img.save(self.avatar.path)
            
class UserPredictModel(models.Model):
    
    AF3 = models.CharField(max_length=100)
    F7 = models.CharField(max_length=100)
    F3 = models.CharField(max_length=100)
    FC5 = models.CharField(max_length=100)
    T7 = models.CharField(max_length=100)
    P7 = models.CharField(max_length=100)
    O1 = models.CharField(max_length=100)
    O2 = models.CharField(max_length=100)
    P8 = models.CharField(max_length=100)
    T8 = models.CharField(max_length=100)
    FC6 = models.CharField(max_length=100)
    F4 = models.CharField(max_length=100)
    F8 = models.CharField(max_length=100)
    AF4 = models.CharField(max_length=100) 
    eyeDetection = models.CharField(max_length=100) 

    # Optionally, add a timestamp for when the prediction was made
def __str__(self):
    return  self.AF3, self.F7, self.F3, self.FC5, self.T7, self.P7, self.O1, self.P8, self.T8, self.FC6, self.F4, self.F8, self.AF4, self.eyeDetection